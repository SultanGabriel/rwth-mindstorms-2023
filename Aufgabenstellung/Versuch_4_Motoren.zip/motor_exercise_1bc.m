%% Aufgabe Motormessungen
% Template for exercise b) and c)


%% Open Bluetooth/USB connetion
% ...


%% Set variables
% ...


%% Create motor object
% ...


%% Do three measurements
% ...


%% Close NXT
% ...


%% Display permant motor position differences
% ...


%% Plot graphs
% ...