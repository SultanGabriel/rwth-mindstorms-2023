%% Lichtsensor-Versuch - Sensor in Schleife auslesen
function lightReadWithLoop(brickObj, numberOfSeconds)

% hier wird keine Initialisierung des Sensors benoetigt!

% Initialisierung der Vektoren, Start der Stoppuhr
% ...

% In einer Schleife für die angegebene Anzahl an Sekunden messen
% ...


% Plotten der Ergebnisse
% ...
