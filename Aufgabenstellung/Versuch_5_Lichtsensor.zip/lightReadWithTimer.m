%% Lichtsensor-Versuch - Sensor timergesteuert auslesen
function lightReadWithTimer(brickObj, numberOfSeconds)

% ... Initialisierung der Vektoren, Starten der Stoppuhr hierher kopieren ...
% ...

% Timer-Objekt anlegen und starten
% ...

% Daten aus Timer-Objekt auslesen.
% ...

% Plotten der Ergebnisse hierher kopieren
% ...


%--------------------------------------------------------------------------

%%
function readLightTimerFcn (timerObj, event)

% UserData aus Timer-Objekt holen
% ...

% Zeit und Sensorwert in Datenstruktur speichern:
% Schleifeninhalt der while-Schleife aus lightReadWithLoop hierher kopieren
% ...

% Daten zurueck in Timer-Objekt sichern
% ...

%--------------------------------------------------------------------------

